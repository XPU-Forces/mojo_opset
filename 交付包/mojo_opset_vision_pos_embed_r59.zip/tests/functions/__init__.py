"""Public operator tests."""
