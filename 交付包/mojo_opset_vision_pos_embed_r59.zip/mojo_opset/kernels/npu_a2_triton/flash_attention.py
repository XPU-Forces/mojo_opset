import math
import heapq

from typing import List, Optional, Tuple

import torch
import triton
import triton.language as tl

from mojo_opset.kernels._npu_triton_utils import get_num_cores
from mojo_opset.kernels._triton_utils import prepare_chunk_indices

def _tensor_to_cpu_list(tensor: torch.Tensor) -> List[int]:
    return [int(x) for x in tensor.detach().cpu().tolist()]

def _build_lpt_task_schedule(
        cu_q_lens: torch.Tensor,
        seqlens_kv: Optional[torch.Tensor],
        num_q_heads: int,
        num_kv_heads: int,
        block_size_m: int,
        block_size_n: int,
        cube_num: int,
        gqa_interleave: bool,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Build a shape-aware static schedule for the 1D Triton grid.

    Each task still computes one (batch, q block, q head). The estimated cost is
    the number of KV blocks scanned by that task. LPT keeps the kernel free of
    global atomics while avoiding the worst tail imbalance of round-robin.
    """
    cu_q_lens_host = _tensor_to_cpu_list(cu_q_lens)
    seqlens_kv_host = None if seqlens_kv is None else _tensor_to_cpu_list(seqlens_kv)
    batch_size = len(cu_q_lens_host) - 1

    weighted_tasks = []
    seq_no = 0
    for b_id in range(batch_size):
        q_seq_len = cu_q_lens_host[b_id + 1] - cu_q_lens_host[b_id]
        if q_seq_len <= 0:
            continue

        kv_seq_len = q_seq_len if seqlens_kv_host is None else seqlens_kv_host[b_id]
        kv_cache_len = kv_seq_len - q_seq_len
        if kv_cache_len < 0:
            raise ValueError(
                f"seqlens_kv[{b_id}] ({kv_seq_len}) must be >= q_seq_len ({q_seq_len})"
            )

        q_chunks = triton.cdiv(q_seq_len, block_size_m)
        for q_block_id in range(q_chunks):
            q_block_end = min((q_block_id + 1) * block_size_m, q_seq_len)
            cost = max(1, triton.cdiv(kv_cache_len + q_block_end, block_size_n))
            for q_head_id in range(num_q_heads):
                if gqa_interleave:
                    kv_head_id = q_head_id % num_kv_heads
                else:
                    kv_head_id = q_head_id // (num_q_heads // num_kv_heads)
                weighted_tasks.append((b_id, kv_head_id, q_block_id, cost, q_head_id, seq_no))
                seq_no += 1

    heap = [(0, core_id) for core_id in range(cube_num)]
    per_core_tasks: List[List[Tuple[int, int, int]]] = [[] for _ in range(cube_num)]

    for b_id, kv_head_id, q_block_id, cost, q_head_id, seq_no in sorted(weighted_tasks, reverse=True):
        core_cost, core_id = heapq.heappop(heap)
        per_core_tasks[core_id].append((b_id, q_head_id, q_block_id))
        heapq.heappush(heap, (core_cost + cost, core_id))

    task_b = []
    task_q_block = []
    task_q_head = []
    core_task_offsets = [0]
    for tasks in per_core_tasks:
        for b_id, q_head_id, q_block_id in tasks:
            task_b.append(b_id)
            task_q_block.append(q_block_id)
            task_q_head.append(q_head_id)
        core_task_offsets.append(len(task_b))

    device = cu_q_lens.device
    return (
        torch.tensor(task_b, device=device, dtype=torch.int32),
        torch.tensor(task_q_block, device=device, dtype=torch.int32),
        torch.tensor(task_q_head, device=device, dtype=torch.int32),
        torch.tensor(core_task_offsets, device=device, dtype=torch.int32),
    )

@triton.jit
def causal_mask_fn(mask_ptr, mask_size, mask_stride_m, mask_stride_n, q_start, kv_start, Q_BLOCK, KV_BLOCK):
    offset_causal = min(max(kv_start - q_start, -mask_size), mask_size)
    offsets_mask_causal = (
        (tl.arange(0, Q_BLOCK)[:, None]) * mask_stride_m
        + (mask_size + offset_causal + tl.arange(0, KV_BLOCK)[None, :]) * mask_stride_n
    )
    mask_causal = tl.load(mask_ptr + offsets_mask_causal).to(tl.int1)

    return mask_causal


@triton.jit
def _sdpa_infer_single_block(
    acc_ptr,
    l_i,
    m_i,
    q,  # Accumulator, local l, local m, query vector
    K_T_block_ptr,
    V_block_ptr,  # Key and value block pointers for current stage
    qk_scale,
    mask,
    HEAD_DIM: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    fp8_v: tl.constexpr,
):
    tl.static_assert(HEAD_DIM <= BLOCK_D, "BLOCK_SIZE_D should not be less than HEAD_DIM")
    # -- Compute qk ----

    # Load (transposed) K block
    k_T = tl.load(K_T_block_ptr, boundary_check=(0, 1), padding_option="zero")
    qk = tl.dot(q, k_T)
    # tl.compile_hint(qk, "tile_cube_loop")

    qk = qk * qk_scale
    if mask is not None:
        qk = tl.where(mask, qk, float("-inf"))  # 32B # bool

    m_ij = tl.maximum(m_i, tl.max(qk, 1, propagate_nan=tl.PropagateNan.ALL), propagate_nan=tl.PropagateNan.ALL)  # Scaled max
    qk = qk - m_ij[:, None]  # Stabilize

    # Softmax weights p = exp(qk)
    p = tl.math.exp(qk)

    p_cast = p.to(k_T.dtype)

    # Load corresponding V block
    v = tl.load(V_block_ptr, boundary_check=(0, 1), padding_option="zero")

    # Softmax denominator (sum of each row)
    l_ij = tl.sum(p, 1)
    # -- Update m_i and l_i
    alpha = tl.math.exp(m_i - m_ij)  # Update factor: exp difference between old and new max
    l_i = l_i * alpha + l_ij  # Update softmax denominator
    # -- Update output accumulator --
    acc_ptr = acc_ptr * alpha[:, None]
    acc_ptr = tl.dot(p_cast, v, acc_ptr)
    # tl.compile_hint(acc_ptr, "tile_cube_loop")

    # Update current block max
    m_i = m_ij

    # NOTE(zhangjihang): for training
    # Return accumulated output acc_ptr, softmax denominator l_i, and max value m_i
    return acc_ptr, l_i, m_i


@triton.jit
def paged_prefill_kernel(
    q_ptr,
    key_cache_ptr,
    value_cache_ptr,
    o_ptr,
    aux_mask_ptr,
    batch_size,
    cu_q_lens_ptr,
    seqlens_kv_ptr,
    block_tables_ptr,
    stride_qt,
    stride_qh,
    stride_qd,
    stride_k_block,
    stride_k_head,
    stride_k_blksz,
    stride_k_dim,
    stride_v_block,
    stride_v_head,
    stride_v_blksz,
    stride_v_dim,
    stride_ot,
    stride_oh,
    stride_od,
    stride_bt_batch,
    stride_bt_block,
    stride_mask_m,
    stride_mask_n,
    softmax_scale,
    AUX_MASK_SIZE: tl.constexpr,
    PAGE_SIZE: tl.constexpr,
    NUM_Q_HEADS: tl.constexpr,
    NUM_KV_HEADS: tl.constexpr,
    GQA_INTERLEAVE: tl.constexpr,
    HEAD_DIM: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_D: tl.constexpr,
):
    pid = tl.program_id(0)
    n_progs = tl.num_programs(0)

    tl.static_assert(PAGE_SIZE % BLOCK_SIZE_N == 0, "BLOCK_SIZE_N must be a divisor of PAGE_SIZE")

    prev_q_chunks = 0

    for b_id in range(batch_size):
        q_start_loc = tl.load(cu_q_lens_ptr + b_id).to(tl.int32)
        q_end_loc = tl.load(cu_q_lens_ptr + b_id + 1).to(tl.int32)
        q_seq_len = q_end_loc - q_start_loc

        if seqlens_kv_ptr is None:
            kv_seq_len = q_seq_len
        else:
            kv_seq_len = tl.load(seqlens_kv_ptr + b_id)
        kv_cache_len = kv_seq_len - q_seq_len

        cur_q_chunks = tl.cdiv(q_seq_len, BLOCK_SIZE_M)
        cur_q_tasks = cur_q_chunks * NUM_Q_HEADS
        prev_q_tasks = prev_q_chunks * NUM_Q_HEADS
        prev_q_chunks += cur_q_chunks
        for q_task_id in range((prev_q_tasks + pid) % n_progs, cur_q_tasks, n_progs):
            q_block_id = q_task_id // NUM_Q_HEADS
            q_head_id = q_task_id % NUM_Q_HEADS

            if GQA_INTERLEAVE:
                kv_head_id = q_head_id % NUM_KV_HEADS
            else:
                kv_head_id = q_head_id // (NUM_Q_HEADS // NUM_KV_HEADS)

            q_block_start_in_seq = q_block_id * BLOCK_SIZE_M
            q_block_end_in_seq = min(q_block_start_in_seq + BLOCK_SIZE_M, q_seq_len)
            q_block_len = q_block_end_in_seq - q_block_start_in_seq

            Q_block_ptr = tl.make_block_ptr(
                base=q_ptr + (q_start_loc + q_block_start_in_seq) * stride_qt + q_head_id * stride_qh,
                shape=(q_block_len, HEAD_DIM),
                strides=(stride_qt, stride_qd),
                offsets=(0, 0),
                block_shape=(BLOCK_SIZE_M, BLOCK_SIZE_D),
                order=(1, 0),
            )
            O_block_ptr = tl.make_block_ptr(
                base=o_ptr + (q_start_loc + q_block_start_in_seq) * stride_ot + q_head_id * stride_oh,
                shape=(q_block_len, HEAD_DIM),
                strides=(stride_ot, stride_od),
                offsets=(0, 0),
                block_shape=(BLOCK_SIZE_M, BLOCK_SIZE_D),
                order=(1, 0),
            )

            q = tl.load(Q_block_ptr, boundary_check=(0, 1), padding_option="zero")

            m_i = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32) - float("inf")
            l_i = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)
            acc = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_D), dtype=tl.float32)

            num_kv_blocks = tl.cdiv(kv_cache_len + q_block_end_in_seq, BLOCK_SIZE_N)

            for kv_block_id in range(0, num_kv_blocks):
                kv_block_start_in_seq = kv_block_id * BLOCK_SIZE_N
                kv_block_end_in_seq = min(kv_block_start_in_seq + BLOCK_SIZE_N, kv_seq_len)
                kv_block_len = kv_block_end_in_seq - kv_block_start_in_seq
                
                logical_page_id = kv_block_start_in_seq // PAGE_SIZE
                kv_block_start_in_page = kv_block_start_in_seq % PAGE_SIZE
                physical_page_id = tl.load(
                    block_tables_ptr + b_id * stride_bt_batch + logical_page_id * stride_bt_block
                )

                K_T_block_ptr = tl.make_block_ptr(
                    base=key_cache_ptr + physical_page_id * stride_k_block + kv_head_id * stride_k_head + kv_block_start_in_page * stride_k_blksz,
                    shape=(HEAD_DIM, kv_block_len),
                    strides=(stride_k_dim, stride_k_blksz),
                    offsets=(0, 0),
                    block_shape=(BLOCK_SIZE_D, BLOCK_SIZE_N),
                    order=(0, 1),
                )
                V_block_ptr = tl.make_block_ptr(
                    base=value_cache_ptr + physical_page_id * stride_v_block + kv_head_id * stride_v_head + kv_block_start_in_page * stride_v_blksz,
                    shape=(kv_block_len, HEAD_DIM),
                    strides=(stride_v_blksz, stride_v_dim),
                    offsets=(0, 0),
                    block_shape=(BLOCK_SIZE_N, BLOCK_SIZE_D),
                    order=(1, 0),
                )

                mask = causal_mask_fn(
                    aux_mask_ptr,
                    AUX_MASK_SIZE,
                    stride_mask_m,
                    stride_mask_n,
                    kv_cache_len + q_block_start_in_seq,
                    kv_block_start_in_seq,
                    BLOCK_SIZE_M,
                    BLOCK_SIZE_N,
                )

                acc, l_i, m_i = _sdpa_infer_single_block(
                    acc,
                    l_i,
                    m_i,
                    q,
                    K_T_block_ptr,
                    V_block_ptr,
                    softmax_scale,
                    mask,
                    HEAD_DIM,
                    BLOCK_SIZE_M,
                    BLOCK_SIZE_N,
                    BLOCK_SIZE_D,
                    value_cache_ptr.dtype.element_ty == tl.float8e5,
                )

            m_i += tl.math.log(l_i)
            accumulator = acc / l_i[:, None]

            # NOTE(zhangjihang): for training
            # m_ptrs = M + task_bn_idx * sub_kv_len + offs_m
            # tl.store(m_ptrs, m_i)
            tl.store(O_block_ptr, accumulator.to(o_ptr.type.element_ty), boundary_check=(0, 1))

def paged_attention_prefill_prepare(
    cu_q_lens,
    seqlens_kv,
    num_q_heads,
    num_kv_heads,
    gqa_interleave,
    page_size,
):
    cube_num = get_num_cores("cube")
    CHUNK_SIZE = 128
    BLOCK_SIZE_N = min(128, triton.next_power_of_2(page_size))

    task_b, task_q_block, task_q_head, core_task_offsets = _build_lpt_task_schedule(
        cu_q_lens,
        seqlens_kv,
        num_q_heads,
        num_kv_heads,
        CHUNK_SIZE,
        BLOCK_SIZE_N,
        cube_num,
        gqa_interleave,
    )
    return task_b, task_q_block, task_q_head, core_task_offsets

def paged_attention_prefill_impl(
    q: torch.Tensor,
    key_cache: torch.Tensor,
    value_cache: torch.Tensor,
    cu_q_lens: torch.Tensor,
    seqlens_kv: Optional[torch.Tensor],
    block_tables: torch.Tensor,
    gqa_interleave: bool,
    task_b: Optional[torch.Tensor],
    task_q_block: Optional[torch.Tensor],
    task_q_head: Optional[torch.Tensor],
    core_task_offsets: Optional[torch.Tensor],
    softmax_scale: Optional[float] = None,
    aux_mask: Optional[torch.Tensor] = None,
    max_q_len: Optional[int] = None,
    max_total_seq_len: Optional[int] = None,
) -> torch.Tensor:
    _, num_q_heads, head_dim = q.shape
    _, num_kv_heads, page_size, _ = key_cache.shape
    batch_size = cu_q_lens.shape[0] - 1

    if softmax_scale is None:
        softmax_scale = 1.0 / math.sqrt(head_dim)

    if aux_mask is None:
        aux_mask = torch.ones(1024, 1024 * 3, device="npu", dtype=torch.bool).tril(1024)

    # Note(chenyifan):
    #   In general, this paged attention kernel works in a `split-q` style.
    #   "bsz * query * q_head" is splited into tasks of shape [BLOCK_SIZE_M, HEAD_DIM]
    #   and then attributed to one program.
    #
    #   Currently, we chunk the queries manually according to a magic CHUNK_SIZE to split queries
    #   It should be better with a autotuned BLOCK_SIZE_M and a pre-configured max_seq_len

    o = torch.empty_like(q)

    CHUNK_SIZE = 128
    BLOCK_SIZE_N = min(128, triton.next_power_of_2(page_size))
    cube_num = get_num_cores("cube")
    grid = (cube_num,)

    paged_prefill_kernel[grid](
        q,
        key_cache,
        value_cache,
        o,
        aux_mask,
        batch_size,
        cu_q_lens,
        seqlens_kv,
        block_tables.to(torch.int32),
        q.stride(0),
        q.stride(1),
        q.stride(2),
        key_cache.stride(0),
        key_cache.stride(1),
        key_cache.stride(2),
        key_cache.stride(3),
        value_cache.stride(0),
        value_cache.stride(1),
        value_cache.stride(2),
        value_cache.stride(3),
        o.stride(0),
        o.stride(1),
        o.stride(2),
        block_tables.stride(0),
        block_tables.stride(1),
        aux_mask.stride(0),
        aux_mask.stride(1),
        softmax_scale,
        aux_mask.shape[0],
        page_size,
        num_q_heads,
        num_kv_heads,
        gqa_interleave,
        head_dim,
        BLOCK_SIZE_M=CHUNK_SIZE,
        BLOCK_SIZE_N=BLOCK_SIZE_N,
        BLOCK_SIZE_D=head_dim,
        limit_auto_multi_buffer_only_for_local_buffer=False,
        set_workspace_multibuffer=4,
    )
    return o


@triton.jit
def paged_decode_kernel(
    q_ptr,
    k_cache_ptr,
    v_cache_ptr,
    o_ptr,
    seqlens_ptr,
    block_tables_ptr,
    BATCH_SIZE,
    NUM_TOTAL_BLOCKS,
    MAX_NUM_BLOCKS_PER_SEQ,
    stride_qb,
    stride_qh,
    stride_qd,
    stride_k_block,
    stride_k_head,
    stride_k_blksz,
    stride_k_dim,
    stride_v_block,
    stride_v_head,
    stride_v_blksz,
    stride_v_dim,
    stride_ob,
    stride_oh,
    stride_od,
    stride_bt_batch,
    stride_bt_block,
    softmax_scale,
    NUM_Q_HEADS: tl.constexpr,
    NUM_KV_HEADS: tl.constexpr,
    GQA_INTERLEAVE: tl.constexpr,
    HEAD_DIM: tl.constexpr,
    PAGE_SIZE: tl.constexpr,
    BLOCK_SIZE_D: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
):
    tl.static_assert(HEAD_DIM <= BLOCK_SIZE_D, "HEAD_DIM should be less than BLOCK_SIZE_D")
    tl.static_assert(PAGE_SIZE % BLOCK_SIZE_N == 0, "BLOCK_SIZE_N must be a divisor of PAGE_SIZE")
    pid = tl.program_id(0)
    n_progs = tl.num_programs(0)

    num_tasks = BATCH_SIZE * NUM_Q_HEADS

    for q_task_id in range(pid, num_tasks, n_progs):
        q_head_id = q_task_id % NUM_Q_HEADS
        b_id = q_task_id // NUM_Q_HEADS
        if GQA_INTERLEAVE:
            kv_head_id = q_head_id % NUM_KV_HEADS
        else:
            kv_head_id = q_head_id // (NUM_Q_HEADS // NUM_KV_HEADS)

        kv_seq_len = tl.load(seqlens_ptr + b_id)


        offs_d = tl.arange(0, BLOCK_SIZE_D)
        q_ptrs = q_ptr + b_id * stride_qb + q_head_id * stride_qh + offs_d * stride_qd
        q = tl.load(q_ptrs, mask = offs_d < HEAD_DIM, other = 0.0)

        m_i = -float("inf")
        l_i = 0.0
        acc = tl.zeros((BLOCK_SIZE_D,), dtype=tl.float32)

        num_kv_blocks = tl.cdiv(kv_seq_len, BLOCK_SIZE_N)

        for kv_block_id in range(0, num_kv_blocks):
            kv_block_start_in_seq = kv_block_id * BLOCK_SIZE_N
            kv_block_end_in_seq = min(kv_block_start_in_seq + BLOCK_SIZE_N, kv_seq_len)
            kv_block_len = kv_block_end_in_seq - kv_block_start_in_seq
            
            logical_page_id = kv_block_start_in_seq // PAGE_SIZE
            kv_block_start_in_page = kv_block_start_in_seq % PAGE_SIZE
            physical_page_id = tl.load(block_tables_ptr + b_id * stride_bt_batch + logical_page_id * stride_bt_block)
            
            k_block_ptr = tl.make_block_ptr(
                base=k_cache_ptr + physical_page_id * stride_k_block + kv_head_id * stride_k_head + kv_block_start_in_page * stride_k_blksz,
                shape=(kv_block_len, HEAD_DIM),
                strides=(stride_k_blksz, stride_k_dim),
                offsets=(0, 0),
                block_shape=(BLOCK_SIZE_N, BLOCK_SIZE_D),
                order=(1, 0),
            )
            v_block_ptr = tl.make_block_ptr(
                base=v_cache_ptr + physical_page_id * stride_v_block + kv_head_id * stride_v_head + kv_block_start_in_page * stride_v_blksz,
                shape=(kv_block_len, HEAD_DIM),
                strides=(stride_v_blksz, stride_v_dim),
                offsets=(0, 0),
                block_shape=(BLOCK_SIZE_N, BLOCK_SIZE_D),
                order=(1, 0),
            )

            mask = tl.arange(0, BLOCK_SIZE_N) < kv_block_len

            k = tl.load(k_block_ptr, boundary_check=(0, 1), padding_option="zero")

            qk = tl.sum((q[None, :] * k).to(tl.float32), axis=1)
            qk *= softmax_scale
            qk = tl.where(mask, qk, float("-inf"))

            m_j = tl.max(qk, axis=0,propagate_nan=tl.PropagateNan.ALL)
            m_ij = tl.maximum(m_i, m_j,propagate_nan=tl.PropagateNan.ALL)
            qk = qk - m_ij

            p = tl.math.exp(qk)

            p_cast = p.to(k.dtype)
            
            v = tl.load(v_block_ptr, boundary_check=(0, 1), padding_option="zero")

            l_ij = tl.sum(p, axis=0)

            alpha = tl.math.exp(m_i - m_ij)

            l_i = l_i * alpha + l_ij

            acc = acc * alpha

            # p = p.to(v.dtype)

            acc += tl.sum((p_cast[:, None] * v).to(tl.float32), axis=0)

            m_i = m_ij

        m_i += tl.math.log(l_i)
        if kv_seq_len > 0:
            # avoid division by zero
            acc = acc / l_i

        o_ptrs = o_ptr + b_id * stride_ob + q_head_id * stride_oh + offs_d * stride_od
        tl.store(o_ptrs, acc.to(o_ptr.dtype.element_ty), mask=offs_d < HEAD_DIM)


def paged_attention_decode_impl(
    q: torch.Tensor,
    key_cache: torch.Tensor,
    value_cache: torch.Tensor,
    seqlens: torch.Tensor,
    block_tables: torch.Tensor,
    gqa_interleave: bool,
    softmax_scale: Optional[float] = None,
) -> torch.Tensor:
    batch_size, num_q_heads, head_dim = q.shape
    num_total_blocks, num_kv_heads, page_size, head_dim_cache = key_cache.shape

    max_num_blocks_per_seq = block_tables.shape[1]

    assert head_dim == head_dim_cache
    if softmax_scale is None:
        softmax_scale = 1.0 / math.sqrt(head_dim)

    o = torch.empty_like(q)
    
    num_vectors = get_num_cores("vector")
    grid = (num_vectors, )
    BLOCK_SIZE_D = triton.next_power_of_2(head_dim)
    BLOCK_SIZE_N = min(128, triton.next_power_of_2(page_size))

    paged_decode_kernel[grid](
        q,
        key_cache,
        value_cache,
        o,
        seqlens,
        block_tables,
        batch_size,
        num_total_blocks,
        max_num_blocks_per_seq,
        q.stride(0),
        q.stride(1),
        q.stride(2),
        key_cache.stride(0),
        key_cache.stride(1),
        key_cache.stride(2),
        key_cache.stride(3),
        value_cache.stride(0),
        value_cache.stride(1),
        value_cache.stride(2),
        value_cache.stride(3),
        o.stride(0),
        o.stride(1),
        o.stride(2),
        block_tables.stride(0),
        block_tables.stride(1),
        softmax_scale,
        num_q_heads,
        num_kv_heads,
        gqa_interleave,
        head_dim,
        page_size,
        BLOCK_SIZE_D=BLOCK_SIZE_D,
        BLOCK_SIZE_N=BLOCK_SIZE_N,
        multibuffer=False,
    )
    return o

@torch.library.custom_op("mojo_npu_triton_a2::paged_prefill_gqa_infer_fwd", mutates_args=())
def _paged_prefill(query: torch.Tensor, key_cache: torch.Tensor, value_cache: torch.Tensor,
    cu_q_lens: torch.Tensor, block_tables: torch.Tensor, softmax_scale: Optional[float],
    cu_total_seq_lens: Optional[torch.Tensor], mask: Optional[torch.Tensor], max_q_len: Optional[int],
    max_total_seq_len: Optional[int], is_causal: bool, gqa_layout: str, scheduler_metadata: list[torch.Tensor]) -> torch.Tensor:
    if not is_causal or mask is not None:
        raise NotImplementedError("Triton paged prefill requires causal=True and no user mask")
    cu_k = cu_q_lens if cu_total_seq_lens is None else cu_total_seq_lens
    lengths = cu_k[1:] - cu_k[:-1]
    metadata = (None, None, None, None)
    return paged_attention_prefill_impl(query, key_cache, value_cache, cu_q_lens, lengths,
        block_tables, gqa_layout == "ABAB", *metadata, softmax_scale, None, max_q_len, max_total_seq_len)


@_paged_prefill.register_fake
def _paged_prefill_fake(query, key_cache, value_cache, cu_q_lens, block_tables, softmax_scale,
                        cu_total_seq_lens, mask, max_q_len, max_total_seq_len, is_causal, gqa_layout, scheduler_metadata):
    return torch.empty_like(query)

def _prepare_paged_prefill(cu_q_lens, cu_total_seq_lens, num_q_heads, num_kv_heads, page_size, gqa_layout):
    return []


def paged_prefill_gqa_infer_fwd(query, key_cache, value_cache, cu_q_lens, block_tables,
                               softmax_scale, cu_total_seq_lens, mask, max_q_len,
                               max_total_seq_len, is_causal, gqa_layout, scheduler_metadata=None):
    if scheduler_metadata is None:
        scheduler_metadata = _prepare_paged_prefill(
            cu_q_lens, cu_total_seq_lens, query.shape[1], key_cache.shape[1],
            key_cache.shape[2], gqa_layout,
        )
    return _paged_prefill(query, key_cache, value_cache, cu_q_lens, block_tables,
                           softmax_scale, cu_total_seq_lens, mask, max_q_len,
                           max_total_seq_len, is_causal, gqa_layout, scheduler_metadata)


paged_prefill_gqa_infer_fwd.prepare_metadata = _prepare_paged_prefill


@torch.library.custom_op("mojo_npu_triton_a2::paged_decode_gqa_infer_fwd", mutates_args=())
def paged_decode_gqa_infer_fwd(query: torch.Tensor, key_cache: torch.Tensor, value_cache: torch.Tensor,
    total_seq_lens: torch.Tensor, block_tables: torch.Tensor, softmax_scale: Optional[float],
    mask: Optional[torch.Tensor], max_total_seq_len: Optional[int], is_causal: bool,
    gqa_layout: str) -> torch.Tensor:
    if not is_causal or mask is not None:
        raise NotImplementedError("Triton paged decode requires causal=True and no user mask")
    return paged_attention_decode_impl(query, key_cache, value_cache, total_seq_lens, block_tables,
                                       gqa_layout == "ABAB", softmax_scale)


@paged_decode_gqa_infer_fwd.register_fake
def _paged_decode_fake(query, key_cache, value_cache, total_seq_lens, block_tables,
                       softmax_scale, mask, max_total_seq_len, is_causal, gqa_layout):
    return torch.empty_like(query)
