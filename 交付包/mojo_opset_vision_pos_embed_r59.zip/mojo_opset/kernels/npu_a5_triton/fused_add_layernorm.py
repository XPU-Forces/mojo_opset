import torch
import triton
import triton.language as tl

from mojo_opset.kernels._npu_triton_utils import libentry

from mojo_opset.kernels._npu_triton_utils import VEC_ALIGN_BYTES
from mojo_opset.kernels._triton_utils import align
from mojo_opset.kernels._triton_utils import ceil_div

COL_BLOCKING_THRESHOLD = 2048
TOKEN_BLOCK_SIZE_TABLE = {
    2048: 4,
    1024: 8,
    512: 10,
    256: 18,
    128: 24,
}


def layer_norm_fwd_heuristics(args):
    hidden_dim = args["n_cols"]
    if hidden_dim <= COL_BLOCKING_THRESHOLD:
        if hidden_dim in TOKEN_BLOCK_SIZE_TABLE:
            return TOKEN_BLOCK_SIZE_TABLE[hidden_dim]

        for dim_thresh, block_size in sorted(TOKEN_BLOCK_SIZE_TABLE.items()):
            if hidden_dim <= dim_thresh:
                return block_size
        return 1
    else:
        return 4


@libentry()
@triton.heuristics({"BLOCK_SIZE_M": layer_norm_fwd_heuristics})
@triton.jit
def _fused_add_layernorm_fwd_kernel(
    Y_ptr,
    Y_row_stride,
    S_ptr,
    S_row_stride,
    X_ptr,
    X_row_stride,
    R_ptr,
    R_row_stride,
    W_ptr,
    B_ptr,
    Mean_ptr,
    Mean_row_stride,
    RSTD_ptr,
    RSTD_row_stride,
    n_rows,
    n_cols,
    eps,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    grid_size = tl.num_programs(axis=0)
    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M

    for row_task_id in range(pid, num_row_tasks, grid_size):
        block_start_row = row_task_id * BLOCK_SIZE_M
        rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)
        rows_mask = rows_off < n_rows

        X_ptr_row_block = X_ptr + rows_off[:, None] * X_row_stride
        R_ptr_row_block = R_ptr + rows_off[:, None] * R_row_stride
        S_ptr_row_block = S_ptr + rows_off[:, None] * S_row_stride
        Y_ptr_row_block = Y_ptr + rows_off[:, None] * Y_row_stride

        mean_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)
        var_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)
        for col_offset in range(0, n_cols, BLOCK_SIZE_N):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)
            block_mask = rows_mask[:, None] & (cols_off[None, :] < n_cols)

            X_chunk = tl.load(X_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0)
            R_chunk = tl.load(R_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0)
            S_chunk = X_chunk + R_chunk
            tl.store(S_ptr_row_block + cols_off[None, :], S_chunk, mask=block_mask)

            S_chunk_f32 = S_chunk.to(tl.float32)
            mean_acc += tl.sum(S_chunk_f32, axis=1)
            var_acc += tl.sum(S_chunk_f32 * S_chunk_f32, axis=1)

        mean_vec = mean_acc / n_cols
        var_vec = (var_acc / n_cols) - (mean_vec * mean_vec)
        rstd_vec = tl.rsqrt(var_vec + eps)
        tl.store(Mean_ptr + rows_off * Mean_row_stride, mean_vec, mask=rows_mask)
        tl.store(RSTD_ptr + rows_off * RSTD_row_stride, rstd_vec, mask=rows_mask)

        for col_offset in range(0, n_cols, BLOCK_SIZE_N):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)
            cols_mask = cols_off < n_cols
            block_mask = rows_mask[:, None] & cols_mask[None, :]

            S_chunk = tl.load(S_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0).to(tl.float32)
            W_chunk = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0)
            B_chunk = tl.load(B_ptr + cols_off, mask=cols_mask, other=0.0)

            normed_S_chunk = (S_chunk - mean_vec[:, None]) * rstd_vec[:, None]
            Y_chunk = normed_S_chunk * W_chunk[None, :] + B_chunk[None, :]
            tl.store(Y_ptr_row_block + cols_off[None, :], Y_chunk.to(Y_ptr.dtype.element_ty), mask=block_mask)


@libentry()
@triton.heuristics({"BLOCK_SIZE_M": lambda args: ceil_div(4096, args["n_cols"])})
@triton.jit
def _fused_add_layernorm_bwd_kernel(
    dY_ptr,
    dY_row_stride,
    dS_out_ptr,
    dS_out_row_stride,
    dX_ptr,
    dX_row_stride,
    S_ptr,
    S_row_stride,
    W_ptr,
    Mean_ptr,
    RSTD_ptr,
    dW_ptr,
    dW_row_stride,
    dB_ptr,
    dB_row_stride,
    n_rows,
    n_cols,
    has_dS_out: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    grid_size = tl.num_programs(axis=0)
    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M

    dW_acc_ptr = dW_ptr + pid * dW_row_stride
    dB_acc_ptr = dB_ptr + pid * dB_row_stride

    for row_task_id in range(pid, num_row_tasks, grid_size):
        block_start_row = row_task_id * BLOCK_SIZE_M
        rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)
        rows_mask = rows_off < n_rows

        mean_vec = tl.load(Mean_ptr + rows_off, mask=rows_mask, other=0.0).to(tl.float32)
        rstd_vec = tl.load(RSTD_ptr + rows_off, mask=rows_mask, other=0.0).to(tl.float32)

        S_ptr_row_block = S_ptr + rows_off[:, None] * S_row_stride
        dY_ptr_row_block = dY_ptr + rows_off[:, None] * dY_row_stride
        dS_out_ptr_row_block = dS_out_ptr + rows_off[:, None] * dS_out_row_stride if has_dS_out else None

        ds_dx_hat_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)
        ds_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)

        for col_offset in range(0, n_cols, BLOCK_SIZE_N):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)
            cols_mask = cols_off < n_cols
            block_mask = rows_mask[:, None] & cols_mask[None, :]

            S_chunk = tl.load(S_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0).to(tl.float32)
            dY_chunk = tl.load(dY_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0).to(tl.float32)
            W_chunk = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)

            S_hat_chunk = (S_chunk - mean_vec[:, None]) * rstd_vec[:, None]
            dY_W_chunk = dY_chunk * W_chunk[None, :]

            ds_dx_hat_acc += tl.sum(dY_W_chunk * S_hat_chunk, axis=1)
            ds_acc += tl.sum(dY_W_chunk, axis=1)

            dW_chunk_acc = tl.sum(dY_chunk * S_hat_chunk, axis=0)
            dB_chunk_acc = tl.sum(dY_chunk, axis=0)
            tl.atomic_add(dW_acc_ptr + cols_off, dW_chunk_acc, mask=cols_mask)
            tl.atomic_add(dB_acc_ptr + cols_off, dB_chunk_acc, mask=cols_mask)

        dX_ptr_row_block = dX_ptr + rows_off[:, None] * dX_row_stride
        for col_offset in range(0, n_cols, BLOCK_SIZE_N):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)
            cols_mask = cols_off < n_cols
            block_mask = rows_mask[:, None] & cols_mask[None, :]

            S_chunk = tl.load(S_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0).to(tl.float32)
            dY_chunk = tl.load(dY_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0).to(tl.float32)
            W_chunk = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)

            S_hat_chunk = (S_chunk - mean_vec[:, None]) * rstd_vec[:, None]
            dY_W_chunk = dY_chunk * W_chunk[None, :]

            grad_of_norm_input = (
                dY_W_chunk - (S_hat_chunk * ds_dx_hat_acc[:, None] + ds_acc[:, None]) / n_cols
            ) * rstd_vec[:, None]

            dS_block = grad_of_norm_input
            if has_dS_out:
                dS_out_chunk = tl.load(dS_out_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0)
                dS_block += dS_out_chunk.to(dS_block.dtype)

            tl.store(dX_ptr_row_block + cols_off[None, :], dS_block.to(dX_ptr.dtype.element_ty), mask=block_mask)


def fused_add_layernorm_infer_impl(
    hidden_states: torch.Tensor,
    residual: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    add_mode: str = "pre",
    eps: float = 1e-6,
):
    shape = hidden_states.shape
    dim = shape[-1]
    X_2d = hidden_states.reshape(-1, dim)
    R_2d = residual.reshape(-1, dim)
    n_rows, n_cols = X_2d.shape

    if n_cols > COL_BLOCKING_THRESHOLD:
        BLOCK_SIZE_N = COL_BLOCKING_THRESHOLD
    else:
        BLOCK_SIZE_N = align(X_2d, n_cols, VEC_ALIGN_BYTES)

    num_programs = triton.runtime.driver.active.utils.get_device_properties("npu")["num_vectorcore"]
    grid = (num_programs,)

    Mean = torch.empty(n_rows, dtype=torch.float32, device=hidden_states.device)
    RSTD = torch.empty(n_rows, dtype=torch.float32, device=hidden_states.device)

    Y = torch.empty_like(X_2d)
    S = torch.empty_like(X_2d)

    _fused_add_layernorm_fwd_kernel[grid](
        Y,
        Y.stride(0),
        S,
        S.stride(0),
        X_2d,
        X_2d.stride(0),
        R_2d,
        R_2d.stride(0),
        weight,
        bias,
        Mean,
        Mean.stride(0),
        RSTD,
        RSTD.stride(0),
        n_rows,
        n_cols,
        eps,
        BLOCK_SIZE_N=BLOCK_SIZE_N,
    )

    if add_mode == "pre":
        return Y.reshape(*shape), S.reshape(*shape)
    elif add_mode == "post":
        return Y.reshape(*shape), Y.reshape(*shape)
    else:
        raise ValueError(f"Invalid add_mode: '{add_mode}'. Must be 'pre' or 'post'.")


@torch.library.custom_op("mojo_npu_triton_a5::residual_add_layer_norm_infer", mutates_args=())
def residual_add_layer_norm_infer_fwd(
    x: torch.Tensor, residual: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor, eps: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    return fused_add_layernorm_infer_impl(
        x.contiguous(), residual.contiguous(), weight.contiguous(), bias.contiguous(), "pre", eps
    )


@residual_add_layer_norm_infer_fwd.register_fake
def _residual_add_layer_norm_infer_fake(x, residual, weight, bias, eps):
    return (torch.empty_like(x, memory_format=torch.contiguous_format),
            torch.empty_like(x, memory_format=torch.contiguous_format))
