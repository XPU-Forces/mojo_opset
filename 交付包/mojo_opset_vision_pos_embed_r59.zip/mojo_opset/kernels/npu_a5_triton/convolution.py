# Copyright (c) 2023-2025, Songlin Yang, Yu Zhang, Wenshuo Zhao


from typing import Optional

import torch
import triton
import triton.language as tl

from mojo_opset.kernels._npu_triton_utils import get_num_cores
from mojo_opset.kernels._triton_utils import input_guard
from mojo_opset.kernels._triton_utils import prepare_chunk_indices

from .silu import silu_bwd

@triton.autotune(
    configs=[
        triton.Config({"BD": BD})
        for BD in [128, 256, 4096]
    ],
    key=["T", "D"],
)
@triton.heuristics(
    {
        "HAS_WEIGHT": lambda args: args["weight"] is not None,
        "HAS_BIAS": lambda args: args["bias"] is not None,
        "HAS_RESIDUAL": lambda args: args["residual"] is not None,
        "USE_INITIAL_STATE": lambda args: args["initial_state"] is not None,
        "IS_VARLEN": lambda args: args["cu_seqlens"] is not None,
    }
)
@triton.jit
def causal_conv1d_fwd_kernel(
    x,
    y,
    weight,
    bias,
    residual,
    cu_seqlens,
    initial_state,
    chunk_indices,
    B,
    T,
    D: tl.constexpr,
    W: tl.constexpr,
    BT: tl.constexpr,
    BD: tl.constexpr,
    ACTIVATION: tl.constexpr,
    HAS_WEIGHT: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    HAS_RESIDUAL: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    NUM_CHKS: tl.int32,
):
    NUM_BLKS_D = tl.cdiv(D, BD)
    pid = tl.program_id(0)
    num_programs = tl.num_programs(0)

    total_tasks = NUM_BLKS_D * NUM_CHKS

    for task_id in range(pid, total_tasks, num_programs):
        i_d_blk = task_id % NUM_BLKS_D
        i_chk = task_id // NUM_BLKS_D

        i_d = i_d_blk

        if IS_VARLEN:
            idx_ptr = chunk_indices + i_chk * 2
            i_n = tl.load(idx_ptr).to(tl.int32)
            i_t = tl.load(idx_ptr + 1).to(tl.int32)

            bos = tl.load(cu_seqlens + i_n).to(tl.int64)
            eos = tl.load(cu_seqlens + i_n + 1).to(tl.int64)
            T_len = eos - bos
        else:
            NT_per_seq = tl.cdiv(T, BT)
            i_b = i_chk // NT_per_seq
            i_t = i_chk % NT_per_seq

            i_n = i_b
            bos = (i_b * T).to(tl.int64)
            eos = (i_b * T + T).to(tl.int64)
            T_len = T

        o_d = i_d * BD + tl.arange(0, BD)
        o_w = tl.arange(0, W)
        m_d = o_d < D
        m_w = o_w >= 0

        if HAS_WEIGHT:
            p_w = tl.make_block_ptr(weight, (W, D), (D, 1), (0, i_d * BD), (W, BD), (1, 0))
            b_w = tl.load(p_w, boundary_check=(0, 1))

        b_y = tl.zeros((BT, BD), dtype=tl.float32)

        yi_offset_1 = i_d * BD + tl.arange(0, BD)[None, :]

        if not USE_INITIAL_STATE:
            for i_w in tl.static_range(-W + 1, 1):
                yi_offset_0 = i_t * BT + i_w + tl.arange(0, BT)[:, None]

                mask = (yi_offset_0 < T_len) & (yi_offset_1 < D) & (yi_offset_0 >= 0)
                # We keep intra loop load because preloading will cause ub overflow under certain tiling.
                b_yi = tl.load(x + bos * D + yi_offset_0 * D + yi_offset_1, mask=mask, other=0.0).to(tl.float32)
                if HAS_WEIGHT:
                    b_yi *= tl.extra.cann.extension.extract_slice(b_w, [i_w + W - 1, 0], [1, BD], [1, 1])

                b_y += b_yi
        elif i_t * BT >= W:
            for i_w in tl.static_range(-W + 1, 1):
                yi_offset_0 = i_t * BT + i_w + tl.arange(0, BT)[:, None]
                mask = (yi_offset_0 < T_len) & (yi_offset_1 < D) & (yi_offset_0 >= 0)
                b_yi = tl.load(x + bos * D + yi_offset_0 * D + yi_offset_1, mask=mask, other=0.0).to(tl.float32)
                if HAS_WEIGHT:
                    b_yi *= tl.extra.cann.extension.extract_slice(b_w, [i_w + W - 1, 0], [1, BD], [1, 1])
                b_y += b_yi
        else:
            o_t = i_t * BT + tl.arange(0, BT)
            for i_w in tl.static_range(-W + 1, 1):
                o_x = o_t + i_w

                m_x = ((o_x >= 0) & (o_x < T_len))[:, None] & m_d

                m_c = ((o_x + W >= 0) & (o_x < 0))[:, None] & m_d

                b_yi = tl.load(x + bos * D + o_x[:, None] * D + o_d, mask=m_x, other=0).to(tl.float32)

                b_yi += tl.load(initial_state + i_n * D * W + o_d * W + (o_x + W)[:, None], mask=m_c, other=0).to(
                    tl.float32
                )

                if HAS_WEIGHT:
                    b_yi *= tl.extra.cann.extension.extract_slice(b_w, [i_w + W - 1, 0], [1, BD], [1, 1])
                b_y += b_yi

        if HAS_BIAS:
            b_y += tl.load(bias + o_d, mask=m_d).to(tl.float32)

        if ACTIVATION == "swish" or ACTIVATION == "silu":
            b_y = b_y * tl.sigmoid(b_y)

        if HAS_RESIDUAL:
            p_residual = tl.make_block_ptr(
                residual + bos * D, (T_len, D), (D, 1), (i_t * BT, i_d * BD), (BT, BD), (1, 0)
            )
            b_residual = tl.load(p_residual, boundary_check=(0, 1))
            b_y += b_residual

        out_t = i_t * BT + tl.arange(0, BT)
        out_offsets = (bos + out_t[:, None]) * D + o_d[None, :]
        tl.store(y + out_offsets, b_y.to(y.dtype.element_ty), mask=(out_t[:, None] < T_len) & m_d[None, :])


@triton.heuristics(
    {
        "HAS_WEIGHT": lambda args: args["dw"] is not None,
        "HAS_BIAS": lambda args: args["db"] is not None,
        "USE_INITIAL_STATE": lambda args: args["dh0"] is not None,
        "USE_FINAL_STATE": lambda args: args["dht"] is not None,
        "IS_VARLEN": lambda args: args["cu_seqlens"] is not None,
    }
)
@triton.jit
def causal_conv1d_bwd_kernel(
    x,
    y,
    weight,
    initial_state,
    dh0,
    dht,
    dy,
    dx,
    dw,
    db,
    cu_seqlens,
    chunk_indices,
    B,
    T,
    D: tl.constexpr,
    W: tl.constexpr,
    BT: tl.constexpr,
    BD: tl.constexpr,
    ACTIVATION: tl.constexpr,
    HAS_WEIGHT: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,
    USE_FINAL_STATE: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    NUM_Blk_D: tl.int32,
    NUM_CHKS: tl.int32,
):
    pid = tl.program_id(0)
    num_programs = tl.num_programs(0)

    total_tasks = NUM_CHKS * NUM_Blk_D

    for task_id in range(pid, total_tasks, num_programs):
        i_d = task_id % NUM_Blk_D
        i_chk = task_id // NUM_Blk_D

        if IS_VARLEN:
            i_t = i_chk

            idx_chk = i_chk

            i_tg = idx_chk

            ptr = chunk_indices + idx_chk * 2
            i_n = tl.load(ptr).to(tl.int32)
            i_t_offset = tl.load(ptr + 1).to(tl.int32)

            i_t = i_t_offset

            bos = tl.load(cu_seqlens + i_n).to(tl.int64)
            eos = tl.load(cu_seqlens + i_n + 1).to(tl.int64)
            T_len = eos - bos
        else:
            NT_per_seq = tl.cdiv(T, BT)

            i_b = i_chk // NT_per_seq
            i_t = i_chk % NT_per_seq

            i_tg = i_chk

            i_n = i_b
            bos = (i_b * T).to(tl.int64)
            eos = (i_b * T + T).to(tl.int64)
            T_len = T

        o_d = i_d * BD + tl.arange(0, BD)
        o_w = tl.arange(0, W)
        m_d = o_d < D
        m_w = o_w >= 0

        if HAS_WEIGHT:
            p_x = tl.make_block_ptr(x + bos * D, (T_len, D), (D, 1), (i_t * BT, i_d * BD), (BT, BD), (1, 0))
            b_x = tl.load(p_x, boundary_check=(0, 1), padding_option="zero")

            p_w = tl.make_block_ptr(weight, (W, D), (D, 1), (0, i_d * BD), (W, BD), (1, 0))
            b_w = tl.load(p_w, boundary_check=(0, 1), padding_option="zero")

        b_dx = tl.zeros((BT, BD), dtype=tl.float32)
        if HAS_BIAS:
            b_db = tl.zeros((BD,), dtype=tl.float32)

        if not USE_INITIAL_STATE:
            b_dw = tl.zeros((W, BD), dtype=tl.float32)

            p_dy = tl.make_block_ptr(dy + bos * D, (T_len, D), (D, 1), (i_t * BT, i_d * BD), (BT * W, BD), (1, 0))
            b_dy = tl.load(p_dy, boundary_check=(0, 1), padding_option="zero").to(tl.float32)

            if ACTIVATION == "swish" or ACTIVATION == "silu":
                p_y = tl.make_block_ptr(y + bos * D, (T_len, D), (D, 1), (i_t * BT, i_d * BD), (BT * W, BD), (1, 0))
                b_y = tl.load(p_y, boundary_check=(0, 1), padding_option="zero").to(tl.float32)

            for i_w in tl.static_range(0, W):
                b_dy_sub = tl.extra.cann.extension.extract_slice(b_dy, [i_w, 0], [BT, BD], [1, 1])

                if ACTIVATION == "swish" or ACTIVATION == "silu":
                    b_y_sub = tl.extra.cann.extension.extract_slice(b_y, [i_w, 0], [BT, BD], [1, 1])
                    b_ys = tl.sigmoid(b_y_sub)
                    b_dy_sub = b_dy_sub * b_ys * (1 + b_y_sub * (1 - b_ys))

                b_wdy = b_dy_sub
                if HAS_WEIGHT:
                    b_wdy = b_wdy * tl.extra.cann.extension.extract_slice(b_w, [W - i_w - 1, 0], [1, BD], [1, 1])

                    b_dw_sub = tl.sum(b_dy_sub * b_x, 0)  # [BT, BD] * [BT, BD] --> sum(0) = [BD]
                    b_dw = tl.extra.cann.extension.insert_slice(b_dw, b_dw_sub[None, :], [W - i_w - 1, 0], [1, BD], [1, 1])

                if HAS_BIAS and i_w == 0:
                    b_db += tl.sum(b_dy_sub, 0)
                b_dx += b_wdy

            p_dw = tl.make_block_ptr(dw + i_tg * W * D, (W, D), (D, 1), (0, i_d * BD), (W, BD), (1, 0))
            tl.store(p_dw, b_dw.to(dw.dtype.element_ty))
        elif i_t * BT >= W:
            for i_w in tl.static_range(0, W):
                p_dy = tl.make_block_ptr(dy + bos * D, (T_len, D), (D, 1), (i_t * BT + i_w, i_d * BD), (BT, BD), (1, 0))

                b_dy = tl.load(p_dy, boundary_check=(0, 1), padding_option="zero").to(tl.float32)
                if ACTIVATION == "swish" or ACTIVATION == "silu":
                    p_y = tl.make_block_ptr(
                        y + bos * D, (T_len, D), (D, 1), (i_t * BT + i_w, i_d * BD), (BT, BD), (1, 0)
                    )
                    b_y = tl.load(p_y, boundary_check=(0, 1), padding_option="zero").to(tl.float32)
                    b_ys = tl.sigmoid(b_y)
                    b_dy = b_dy * b_ys * (1 + b_y * (1 - b_ys))
                b_wdy = b_dy
                if HAS_WEIGHT:
                    b_wdy = b_wdy * tl.extra.cann.extension.extract_slice(b_w, [W - i_w - 1, 0], [1, BD], [1, 1])

                    b_dw = tl.sum(b_dy * b_x, 0)
                    tl.store(dw + i_tg * D * W + (W - i_w - 1) * D + o_d, b_dw.to(dw.dtype.element_ty), mask=m_d)
                if HAS_BIAS and i_w == 0:
                    b_db += tl.sum(b_dy, 0)
                b_dx += b_wdy
        else:
            o_t = i_t * BT + tl.arange(0, BT)
            for i_w in tl.static_range(0, W):
                p_dy = tl.make_block_ptr(dy + bos * D, (T_len, D), (D, 1), (i_t * BT + i_w, i_d * BD), (BT, BD), (1, 0))
                b_dy_shift = tl.load(p_dy, boundary_check=(0, 1), padding_option="zero").to(tl.float32)
                if ACTIVATION == "swish" or ACTIVATION == "silu":
                    p_y = tl.make_block_ptr(
                        y + bos * D, (T_len, D), (D, 1), (i_t * BT + i_w, i_d * BD), (BT, BD), (1, 0)
                    )
                    b_y = tl.load(p_y, boundary_check=(0, 1), padding_option="zero").to(tl.float32)
                    b_ys = tl.sigmoid(b_y)
                    b_dy_shift = b_dy_shift * b_ys * (1 + b_y * (1 - b_ys))
                if HAS_WEIGHT:
                    b_dw = tl.sum(b_dy_shift * b_x, 0)

                    if USE_INITIAL_STATE:
                        mask_head_rows = (o_t < i_w) & (o_t < T_len)

                        b_dy_head = tl.load(
                            dy + bos * D + o_t[:, None] * D + o_d,
                            mask=(mask_head_rows[:, None] & m_d[None, :]),
                            other=0.0,
                        ).to(tl.float32)
                        if ACTIVATION == "swish" or ACTIVATION == "silu":
                            b_y_head = tl.load(
                                y + bos * D + o_t[:, None] * D + o_d,
                                mask=(mask_head_rows[:, None] & m_d[None, :]),
                                other=0.0,
                            ).to(tl.float32)
                            b_ys_head = tl.sigmoid(b_y_head)
                            b_dy_head = b_dy_head * b_ys_head * (1 + b_y_head * (1 - b_ys_head))
                        o_c = W - i_w + o_t

                        mask_c = mask_head_rows & (o_c >= 1) & (o_c < W)
                        b_xc = tl.load(
                            initial_state + i_n * D * W + o_d[None, :] * W + o_c[:, None],
                            mask=(mask_c[:, None] & m_d[None, :]),
                            other=0.0,
                        ).to(tl.float32)

                        b_dw += tl.sum(b_dy_head * b_xc, 0)
                    tl.store(dw + i_tg * D * W + (W - i_w - 1) * D + o_d, b_dw.to(dw.dtype.element_ty), mask=m_d)

                if HAS_BIAS and i_w == 0:
                    b_db += tl.sum(b_dy_shift, 0)
                b_wdy = (
                    b_dy_shift
                    if not HAS_WEIGHT
                    else (b_dy_shift * tl.extra.cann.extension.extract_slice(b_w, [W - i_w - 1, 0], [1, BD], [1, 1]))
                )
                b_dx += b_wdy

            if USE_INITIAL_STATE:
                p_dy0 = tl.make_block_ptr(dy + bos * D, (T_len, D), (D, 1), (i_t * BT, i_d * BD), (BT, BD), (1, 0))
                b_dy0 = tl.load(p_dy0, boundary_check=(0, 1), padding_option="zero").to(tl.float32)
                if ACTIVATION == "swish" or ACTIVATION == "silu":
                    p_y0 = tl.make_block_ptr(y + bos * D, (T_len, D), (D, 1), (i_t * BT, i_d * BD), (BT, BD), (1, 0))
                    b_y0 = tl.load(p_y0, boundary_check=(0, 1), padding_option="zero").to(tl.float32)
                    b_ys0 = tl.sigmoid(b_y0)
                    b_dy0 = b_dy0 * b_ys0 * (1 + b_y0 * (1 - b_ys0))

                for i_w in tl.static_range(1, W):
                    m_rows = (o_t < i_w) & (o_t < T_len)
                    if HAS_WEIGHT:
                        w_idx_rows = i_w - 1 - o_t

                        w_mask = o_w[None, :] == w_idx_rows[:, None]
                        w_pick = tl.sum(tl.trans(b_w)[None, :, :] * w_mask[:, None, :], 2)
                    else:
                        w_pick = 1.0
                    contrib = (b_dy0 * w_pick).to(tl.float32)
                    contrib = tl.where(m_rows[:, None] & m_d[None, :], contrib, 0.0)

                    b_dh0_s = tl.sum(contrib, 0)

                    tl.store(
                        dh0 + i_t * B * D * W + i_n * D * W + o_d * W + i_w,
                        b_dh0_s.to(dh0.dtype.element_ty, fp_downcast_rounding="rtne"),
                        mask=m_d,
                    )

        if HAS_BIAS:
            b_db = tl.cast(b_db, dtype=db.dtype.element_ty, fp_downcast_rounding="rtne")
            tl.store(db + i_tg * D + o_d, b_db, mask=m_d)

        if USE_FINAL_STATE:
            if i_t * BT + BT >= T_len - W:
                start_tok = max(0, T_len - (W - 1))
                offset = i_t * BT + tl.arange(0, BT)
                tok_idx = offset - start_tok
                mask = (offset >= start_tok) & (offset < T_len)
                w_idx = 1 + tok_idx
                dht_off = i_n * D * W + o_d[None, :] * W + w_idx[:, None]
                b_dht = tl.load(dht + dht_off, mask=mask[:, None] & m_d[None, :], other=0.0).to(tl.float32)
                b_dx += b_dht

        p_dx = tl.make_block_ptr(dx + bos * D, (T_len, D), (D, 1), (i_t * BT, i_d * BD), (BT, BD), (1, 0))
        tl.store(p_dx, tl.cast(b_dx, dtype=p_dx.dtype.element_ty, fp_downcast_rounding="rtne"), boundary_check=(0, 1))


@input_guard(make_contiguous=True, auto_to_device=True)
def causal_conv1d_fwd_impl(
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    residual: torch.Tensor,
    initial_state: Optional[torch.Tensor] = None,
    output_final_state: bool = False,
    activation: Optional[str] = None,
    cu_seqlens: Optional[torch.Tensor] = None,
    output_float32: bool = False,
) -> torch.Tensor:
    shape = x.shape
    assert x.shape[-1] == weight.shape[-1], "x [B, T, D], weight [W, D], please check."
    B, T, D, W = *x.shape, weight.shape[0]

    NUM_CORES = get_num_cores()

    BT = min(32, triton.next_power_of_2(triton.cdiv(max(16, B * T), NUM_CORES)))


    if cu_seqlens is not None:
        chunk_indices = prepare_chunk_indices(cu_seqlens, BT)
        NUM_CHKS = len(chunk_indices)
    else:
        chunk_indices = None

        NUM_CHKS = triton.cdiv(T, BT) * B

    y = torch.empty_like(x, dtype=torch.float32 if output_float32 else x.dtype)

    grid = (NUM_CORES,)

    causal_conv1d_fwd_kernel[grid](
        x=x,
        y=y,
        weight=weight,
        bias=bias,
        residual=residual,
        cu_seqlens=cu_seqlens,
        initial_state=initial_state,
        chunk_indices=chunk_indices,
        B=B,
        T=T,
        D=D,
        W=W,
        BT=BT,
        ACTIVATION=activation,
        NUM_CHKS=NUM_CHKS,
    )

    final_state = None
    if output_final_state:
        final_state = causal_conv1d_update_states(
            x=x,
            state_len=W,
            initial_state=initial_state,
            cu_seqlens=cu_seqlens,
        )

    return y.view(shape), final_state


def causal_conv1d_bwd_impl(
    x: torch.Tensor,
    dy: torch.Tensor,
    dht: torch.Tensor,
    weight: Optional[torch.Tensor] = None,
    bias: Optional[torch.Tensor] = None,
    residual: Optional[torch.Tensor] = None,
    initial_state: Optional[torch.Tensor] = None,
    activation: str = None,
    cu_seqlens: Optional[torch.Tensor] = None,
):
    shape = x.shape
    assert x.shape[-1] == weight.shape[-1], "x [B, T, D], weight [W, D], please check."

    B, T, D = x.shape
    W = weight.shape[0] if weight is not None else None

    NUM_CORES = get_num_cores()
    BT = min(64, triton.next_power_of_2(triton.cdiv(max(16, B * T), NUM_CORES)))

    BD = 64
    assert D % BD == 0, "D must be divisible by BD."
    NUM_Blk_D = triton.cdiv(D, BD)

    if cu_seqlens is not None:
        chunk_indices = prepare_chunk_indices(cu_seqlens, BT)
        NUM_CHKS = len(chunk_indices)

        NT = len(chunk_indices)
    else:
        chunk_indices = None

        NT = triton.cdiv(T, BT)
        NUM_CHKS = NT * B

    y = None
    if activation is not None:
        y, _ = causal_conv1d_fwd_impl(
            x=x,
            weight=weight,
            bias=bias,
            residual=None,
            initial_state=initial_state,
            activation=None,
            cu_seqlens=cu_seqlens,
            output_final_state=False,
        )
    dx = torch.empty_like(x)
    dw = weight.new_empty(B * NT, W, D, dtype=torch.float) if weight is not None else None
    db = bias.new_empty(B * NT, *bias.shape, dtype=torch.float) if bias is not None else None
    dr = dy if residual is not None else None

    if initial_state is not None:
        if cu_seqlens is not None:
            eff_NT = len(chunk_indices)
        else:
            eff_NT = triton.cdiv(T, BT)

        dh0 = initial_state.new_zeros(min(eff_NT, triton.cdiv(W, BT)), *initial_state.shape)
    else:
        dh0 = None

    grid = (NUM_CORES,)

    causal_conv1d_bwd_kernel[grid](
        x=x,
        y=y,
        weight=weight,
        initial_state=initial_state,
        dh0=dh0,
        dht=dht,
        dy=dy,
        dx=dx,
        dw=dw,
        db=db,
        cu_seqlens=cu_seqlens,
        chunk_indices=chunk_indices,
        B=cu_seqlens.numel() - 1 if cu_seqlens is not None else B,
        T=T,
        D=D,
        W=W,
        BT=BT,
        BD=BD,
        ACTIVATION=activation,
        NUM_Blk_D=NUM_Blk_D,
        NUM_CHKS=NUM_CHKS,
        multibuffer=False,
    )

    if weight is not None:
        dw = dw.sum(0).permute(1, 0).contiguous().to(weight)
    if bias is not None:
        db = db.sum(0).to(bias)
    if initial_state is not None:
        dh0 = dh0.sum(0, dtype=torch.float32).to(initial_state)

    return dx.view(shape), dw, db, dr, dh0


@triton.heuristics(
    {
        "USE_INITIAL_STATE": lambda args: args["initial_state"] is not None,
        "IS_VARLEN": lambda args: args["cu_seqlens"] is not None,
    }
)
@triton.jit
def causal_conv1d_states_fwd_kernel(
    x,
    initial_state,
    final_state,
    cu_seqlens,
    T,
    D,
    W,
    BD: tl.constexpr,
    BW: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_d, i_n = tl.program_id(0), tl.program_id(1)
    if IS_VARLEN:
        bos, eos = tl.load(cu_seqlens + i_n).to(tl.int64), tl.load(cu_seqlens + i_n + 1).to(tl.int64)
        T = eos - bos
    else:
        bos, eos = (i_n * T).to(tl.int64), (i_n * T + T).to(tl.int64)

    o_t = eos - BW + tl.arange(0, BW)
    o_d = i_d * BD + tl.arange(0, BD)
    o_w = W - BW + tl.arange(0, BW)
    m_t = o_t >= tl.maximum(bos, eos - W)
    m_d = o_d < D
    m_w = (o_w >= 0) & (o_w < W)

    b_x = tl.load(x + o_t * D + o_d[:, None], mask=(m_t & m_d[:, None]), other=0)
    if USE_INITIAL_STATE:
        o_c = W - (BW - T) + tl.arange(0, BW)
        m_c = (o_c >= 0) & (o_c < W)
        b_cache = tl.load(initial_state + i_n * D * W + o_d[:, None] * W + o_c, mask=m_d[:, None] & m_c, other=0)
        # Ascend 950 workaround: select history without a runtime T < BW branch
        # that merges b_x across control flow. Current-token lanes keep b_x.
        b_x = tl.where(m_t[None, :], b_x, b_cache)

    tl.store(final_state + i_n * D * W + o_d[:, None] * W + o_w, b_x, mask=m_d[:, None] & m_w)


@input_guard(make_contiguous=True, auto_to_device=True)
def causal_conv1d_update_states(
    x: torch.Tensor,
    state_len: int,
    initial_state: Optional[torch.Tensor] = None,
    cu_seqlens: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    B, T, D, W = *x.shape, state_len
    N = len(cu_seqlens) - 1 if cu_seqlens is not None else B

    final_state = torch.empty(N, D, W, dtype=x.dtype, device=x.device)
    BD = min(triton.next_power_of_2(D), 256)
    BW = W
    grid = (triton.cdiv(D, BD), N)
    causal_conv1d_states_fwd_kernel[grid](
        x=x,
        initial_state=initial_state,
        final_state=final_state,
        cu_seqlens=cu_seqlens,
        T=T,
        D=D,
        W=W,
        BW=BW,
        BD=BD,
    )
    return final_state


@triton.jit()
def causal_conv1d_update_kernel_bdt_fwd(
    x_ptr,  # [B, D, T]
    conv_state_ptr,  # [B, D, ST]
    conv_state_update_ptr,
    weight_ptr,  # [D, W]
    bias_ptr,
    conv_state_indices_ptr,
    out_ptr,  # [B, D, OT]
    batch: tl.constexpr,
    dim: tl.constexpr,
    state_len: tl.constexpr,  # ST
    seq_len: tl.constexpr,  # T
    width: tl.constexpr,  # W
    out_len: tl.constexpr,  # OT
    x_batch_stride: tl.constexpr,
    conv_batch_stride: tl.constexpr,
    out_batch_stride: tl.constexpr,
    HAS_BIAS: tl.constexpr,  # TODO
    SILU_ACTIVATION: tl.constexpr,
    T_CHK_SIZE: tl.constexpr,
    D_CHK_SIZE: tl.constexpr,
    NUM_T_CHK: tl.constexpr,
    NUM_D_CHK: tl.constexpr,
    ST_STORE_HEAD_TILE_SIZE: tl.constexpr,
):
    pid = tl.program_id(0)
    pnum = tl.num_programs(0)

    total_task = batch * NUM_D_CHK * NUM_T_CHK

    for task_id in tl.range(pid, total_task, pnum):
        di = task_id % NUM_D_CHK
        bti = task_id // NUM_D_CHK
        bi = bti // NUM_T_CHK
        ti = bti % NUM_T_CHK

        w_off_d = di * D_CHK_SIZE + tl.arange(0, D_CHK_SIZE)[:, None]
        w_off_w = tl.arange(0, width)[None, :]
        w = tl.load(weight_ptr + w_off_d * width + w_off_w).to(tl.float32)

        if ti == 0:
            st_b = tl.load(
                tl.make_block_ptr(
                    conv_state_ptr + bi * state_len * dim,
                    shape=(dim, state_len),
                    strides=(state_len, 1),
                    offsets=(di * D_CHK_SIZE, state_len - (width - 1)),
                    block_shape=(D_CHK_SIZE, (width - 1) + T_CHK_SIZE),
                    order=(1, 0),
                ),
                boundary_check=(0, 1),
                padding_option="zero",
            )
            x_b_tmp = tl.load(
                tl.make_block_ptr(
                    x_ptr + bi * dim * seq_len,
                    shape=(dim, seq_len),
                    strides=(seq_len, 1),
                    offsets=(di * D_CHK_SIZE, 0),
                    block_shape=(D_CHK_SIZE, T_CHK_SIZE),
                    order=(1, 0),
                ),
                boundary_check=(0, 1),
                padding_option="zero",
            )
            x_b = tl.extra.cann.extension.insert_slice(st_b, x_b_tmp, (0, width - 1), (D_CHK_SIZE, T_CHK_SIZE), (1, 1))
        else:
            x_b = tl.load(
                tl.make_block_ptr(
                    x_ptr + bi * dim * seq_len,
                    shape=(dim, seq_len),
                    strides=(seq_len, 1),
                    offsets=(di * D_CHK_SIZE, ti * T_CHK_SIZE - (width - 1)),
                    block_shape=(D_CHK_SIZE, T_CHK_SIZE + width - 1),
                    order=(1, 0),
                ),
                boundary_check=(0, 1),
                padding_option="zero",
            )

        out_block = tl.zeros((D_CHK_SIZE, T_CHK_SIZE), dtype=tl.float32)
        x_b = x_b.to(tl.float32)

        new_state_start_off = seq_len - state_len
        t_start_off = ti * T_CHK_SIZE - (width - 1)
        t_end_off = (ti + 1) * T_CHK_SIZE
        if t_end_off >= new_state_start_off:
            nst_off_y0 = di * D_CHK_SIZE + tl.arange(0, D_CHK_SIZE)[:, None]
            nst_off_y1 = tl.arange(0, state_len)[None, :]
            nst_mask = (nst_off_y0 < dim) & (nst_off_y1 < state_len)
            block_ptr_st = bi * dim * state_len + nst_off_y0 * state_len + nst_off_y1

            if new_state_start_off < 0:
                cs_src_idx = seq_len + nst_off_y1
                cs_mask = nst_mask & (cs_src_idx < state_len) & (cs_src_idx >= 0)
                cs_off = bi * dim * state_len + nst_off_y0 * state_len + cs_src_idx
                cs_val = tl.load(conv_state_ptr + cs_off, mask=cs_mask, other=0).to(conv_state_update_ptr.dtype.element_ty)
                tl.store(conv_state_update_ptr + block_ptr_st, cs_val, mask=cs_mask)

            src_col_off = new_state_start_off - t_start_off + nst_off_y1
            src_valid = (src_col_off >= 0) & (src_col_off < T_CHK_SIZE + width - 1)
            x_st_off = bi * dim * seq_len + nst_off_y0 * seq_len + (new_state_start_off + nst_off_y1)
            x_st_mask = nst_mask & src_valid & ((new_state_start_off + nst_off_y1) < seq_len) & ((new_state_start_off + nst_off_y1) >= 0)
            x_st = tl.load(x_ptr + x_st_off, mask=x_st_mask, other=0).to(conv_state_update_ptr.dtype.element_ty)
            tl.store(conv_state_update_ptr + block_ptr_st, x_st, mask=x_st_mask)

        for owi in tl.range(0, width):
            new_x = tl.extra.cann.extension.extract_slice(x_b, (0, owi), (D_CHK_SIZE, T_CHK_SIZE), (1, 1))
            w_chl_wi = tl.extra.cann.extension.extract_slice(w, (0, owi), (D_CHK_SIZE, 1), (1, 1))
            out_block += new_x * w_chl_wi

        if SILU_ACTIVATION:
            out_block = out_block / (1.0 + tl.exp(-out_block))
        out_block = out_block.to(out_ptr.type.element_ty)
        out_off_d = di * D_CHK_SIZE + tl.arange(0, D_CHK_SIZE)[:, None]
        out_off_t = ti * T_CHK_SIZE + tl.arange(0, T_CHK_SIZE)[None, :]
        out_mask = (out_off_d < dim) & (out_off_t < out_len)
        out_off = bi * dim * out_len + out_off_d * out_len + out_off_t
        tl.store(out_ptr + out_off, out_block, mask=out_mask)


@input_guard(make_contiguous=True, auto_to_device=True)
def causal_conv1d_update_bdt_impl(
    x: torch.Tensor,
    conv_state: torch.Tensor,
    weight: torch.Tensor,
    bias: Optional[torch.Tensor] = None,
    activation: Optional[str] = None,
    conv_state_indices: Optional[str] = None,
):
    if isinstance(activation, bool):
        activation = "silu" if activation is True else None
    elif activation is not None:
        assert activation in ["silu", "swish"]
    unsqueeze = x.dim() == 2
    if unsqueeze:
        x = x.unsqueeze(-1)
    batch, dim, seqlen = x.shape
    _, width = weight.shape
    out = torch.empty_like(x)
    NUM_CORES = get_num_cores()

    T_CHK_SIZE = 256
    D_CHK_SIZE = 16

    assert T_CHK_SIZE >= width

    NUM_T_CHK = triton.cdiv(out.shape[-1], T_CHK_SIZE)
    NUM_D_CHK = triton.cdiv(dim, D_CHK_SIZE)
    conv_state_update = torch.empty_like(conv_state)

    # A const tile size variable to update negative address of conv state
    ST_STORE_HEAD_TILE_SIZE = width if (seqlen % T_CHK_SIZE) > width else (width - seqlen % T_CHK_SIZE) % T_CHK_SIZE
    causal_conv1d_update_kernel_bdt_fwd[(NUM_CORES, 1)](
        x,
        conv_state,
        conv_state_update,
        weight,
        bias,
        conv_state_indices,
        out,
        batch=int(batch),
        dim=int(dim),
        state_len=int(conv_state.shape[-1]),
        seq_len=int(x.shape[-1]),
        width=int(width),
        out_len=int(out.shape[-1]),
        x_batch_stride=x.stride()[0],
        conv_batch_stride=conv_state.stride()[0],
        out_batch_stride=out.stride()[0],
        HAS_BIAS=bias is not None,
        SILU_ACTIVATION=activation in ["silu", "swish"],
        T_CHK_SIZE=T_CHK_SIZE,
        D_CHK_SIZE=D_CHK_SIZE,
        NUM_T_CHK=NUM_T_CHK,
        NUM_D_CHK=NUM_D_CHK,
        ST_STORE_HEAD_TILE_SIZE=int(ST_STORE_HEAD_TILE_SIZE),
    )
    conv_state.copy_(conv_state_update)
    if unsqueeze:
        out = out.squeeze(-1)
    return out


@torch.library.custom_op("mojo_npu_triton_a5::causal_conv1d_forward", mutates_args=())
def causal_conv1d_forward(
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: Optional[torch.Tensor],
    residual: Optional[torch.Tensor],
    initial_state: Optional[torch.Tensor],
    activation: Optional[str],
    cu_seqlens: Optional[torch.Tensor],
    output_float32: bool = False,
) -> torch.Tensor:
    output, _ = causal_conv1d_fwd_impl(
        x,
        weight.transpose(0, 1).contiguous(),
        bias,
        residual,
        initial_state,
        False,
        activation,
        cu_seqlens,
        output_float32,
    )
    return output


@causal_conv1d_forward.register_fake
def _causal_conv1d_forward_fake(x, weight, bias, residual, initial_state, activation, cu_seqlens, output_float32=False):
    return torch.empty_like(
        x, dtype=torch.float32 if output_float32 else x.dtype, memory_format=torch.contiguous_format
    )


def causal_conv1d_update_state_infer_fwd(x, conv_state, weight, bias, activation):
    if x.shape[-1] == 0:
        return torch.empty_like(x)
    # Reuse the forward and rolling-state leaves, keeping both visible to capture.
    compute_x = x.to(weight.dtype).transpose(1, 2).contiguous()
    compute_state = conv_state.to(weight.dtype)
    history = compute_state[..., compute_state.shape[-1] - (weight.shape[1] - 1):]
    output = causal_conv1d_forward(
        compute_x, weight, bias, None, _padded_state(history).contiguous(), activation, None,
    )
    if conv_state.shape[-1]:
        next_state = causal_conv1d_state(compute_x, compute_state, conv_state.shape[-1], None)
        conv_state.copy_(next_state)
    return output.transpose(1, 2).to(x.dtype).contiguous()


def _padded_state(state):
    return None if state is None else torch.nn.functional.pad(state, (1, 0))


def causal_conv1d_fwd(x, weight, bias, residual, initial_state, output_final_state, activation, cu_seqlens):
    output = causal_conv1d_forward(x, weight, bias, residual, _padded_state(initial_state), activation, cu_seqlens)
    final_state = None
    if output_final_state:
        final_state = causal_conv1d_state(x, initial_state, weight.shape[1] - 1, cu_seqlens)
    return output, final_state


@torch.library.custom_op("mojo_npu_triton_a5::causal_conv1d_state", mutates_args=())
def causal_conv1d_state(
    x: torch.Tensor,
    initial_state: Optional[torch.Tensor],
    state_length: int,
    cu_seqlens: Optional[torch.Tensor],
) -> torch.Tensor:
    # Use the existing independent state-update kernel. Its internal state width
    # includes the unused oldest element; public states contain W - 1 elements.
    padded = _padded_state(initial_state)
    full_state = causal_conv1d_update_states(x, state_length + 1, padded, cu_seqlens)
    return full_state[..., 1:].contiguous()


@causal_conv1d_state.register_fake
def _causal_conv1d_state_fake(x, initial_state, state_length, cu_seqlens):
    batches = x.shape[0] if cu_seqlens is None else cu_seqlens.shape[0] - 1
    return x.new_empty((batches, x.shape[-1], state_length))


@torch.library.custom_op("mojo_npu_triton_a5::causal_conv1d_backward", mutates_args=())
def causal_conv1d_backward(
    dy: torch.Tensor,
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: Optional[torch.Tensor],
    initial_state: Optional[torch.Tensor],
    cu_seqlens: Optional[torch.Tensor],
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    dx, dw, db, _, dh = causal_conv1d_bwd_impl(
        x.contiguous(),
        dy.contiguous(),
        None,
        weight.transpose(0, 1).contiguous(),
        bias,
        None,
        initial_state,
        None,
        cu_seqlens,
    )
    return dx, dw, x.new_empty((0,)) if db is None else db, x.new_empty((0,)) if dh is None else dh


@causal_conv1d_backward.register_fake
def _causal_conv1d_backward_fake(dy, x, weight, bias, initial_state, cu_seqlens):
    return (
        torch.empty_like(x, memory_format=torch.contiguous_format),
        torch.empty_like(weight, memory_format=torch.contiguous_format),
        x.new_empty((0,)) if bias is None else torch.empty_like(bias),
        x.new_empty((0,)) if initial_state is None else torch.empty_like(initial_state),
    )


def causal_conv1d_bwd(dy, dstate, x, weight, bias, residual, initial_state, output_final_state, activation, cu_seqlens):
    padded = _padded_state(initial_state)
    conv_dy = dy
    if activation is not None:
        # Compose existing leaves so both recomputation and the activation
        # derivative remain visible in the backward graph.
        # Keep the derivative intermediate in FP32; BF16 rounding before the
        # weight-gradient reduction would add an avoidable quantization step.
        preactivation = causal_conv1d_forward(x, weight, bias, None, padded, None, cu_seqlens, True)
        conv_dy = silu_bwd(dy, preactivation)
    dx, dw, db, dh = causal_conv1d_backward(conv_dy, x, weight, bias, padded, cu_seqlens)
    dh = None if initial_state is None else dh[..., 1:]
    if output_final_state and dstate is not None:
        sx, sh = causal_conv1d_state_backward(dstate, x, initial_state, cu_seqlens)
        dx = dx + sx
        if dh is not None:
            dh = dh + sh
    return dx, dw, None if bias is None else db, None if residual is None else dy, dh


@torch.library.custom_op("mojo_npu_triton_a5::causal_conv1d_state_backward", mutates_args=())
def causal_conv1d_state_backward(
    dstate: torch.Tensor,
    x: torch.Tensor,
    initial_state: Optional[torch.Tensor],
    cu_seqlens: Optional[torch.Tensor],
) -> tuple[torch.Tensor, torch.Tensor]:
    dx = torch.zeros_like(x, memory_format=torch.contiguous_format)
    dh = (
        x.new_empty((0,))
        if initial_state is None
        else torch.zeros_like(initial_state, memory_format=torch.contiguous_format)
    )
    batches = x.shape[0] if cu_seqlens is None else cu_seqlens.shape[0] - 1
    width = dstate.shape[-1]
    grid = (triton.cdiv(x.shape[-1], 64), batches)
    _state_backward_kernel[grid](
        dstate.contiguous(),
        dx,
        dh,
        cu_seqlens,
        x.shape[1],
        x.shape[-1],
        width,
        HAS_INITIAL=initial_state is not None,
        VARLEN=cu_seqlens is not None,
        BD=64,
        BW=triton.next_power_of_2(max(width, 1)),
    )
    return dx, dh


@causal_conv1d_state_backward.register_fake
def _causal_conv1d_state_backward_fake(dstate, x, initial_state, cu_seqlens):
    return (
        torch.empty_like(x, memory_format=torch.contiguous_format),
        x.new_empty((0,))
        if initial_state is None
        else torch.empty_like(initial_state, memory_format=torch.contiguous_format),
    )


@triton.jit
def _state_backward_kernel(
    ds,
    dx,
    dh,
    cu,
    T,
    D: tl.constexpr,
    W: tl.constexpr,
    HAS_INITIAL: tl.constexpr,
    VARLEN: tl.constexpr,
    BD: tl.constexpr,
    BW: tl.constexpr,
):
    batch = tl.program_id(1)
    d = tl.program_id(0) * BD + tl.arange(0, BD)
    w = tl.arange(0, BW)
    if VARLEN:
        start = tl.load(cu + batch)
        end = tl.load(cu + batch + 1)
    else:
        start = batch * T
        end = start + T
    length = end - start
    pos = length - W + w
    g = tl.load(ds + batch * D * W + d[:, None] * W + w[None, :], mask=(d[:, None] < D) & (w[None, :] < W), other=0)
    tl.store(
        dx + (start + pos[None, :]) * D + d[:, None], g, mask=(d[:, None] < D) & (w[None, :] < W) & (pos[None, :] >= 0)
    )
    if HAS_INITIAL:
        tl.store(
            dh + batch * D * W + d[:, None] * W + (pos + W)[None, :],
            g,
            mask=(d[:, None] < D) & (w[None, :] < W) & (pos[None, :] < 0),
        )
